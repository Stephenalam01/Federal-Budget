import { ModelInit, MutableModel, PersistentModelConstructor } from "@aws-amplify/datastore";





type AgencyModelMetaData = {
  readOnlyFields: 'createdAt' | 'updatedAt';
}

export declare class AgencyModel {
  readonly id: string;
  readonly AgencyName?: string | null;
  readonly Budget?: number | null;
  readonly NumberOfDepartments: number;
  readonly createdAt?: string | null;
  readonly updatedAt?: string | null;
  constructor(init: ModelInit<AgencyModel, AgencyModelMetaData>);
  static copyOf(source: AgencyModel, mutator: (draft: MutableModel<AgencyModel, AgencyModelMetaData>) => MutableModel<AgencyModel, AgencyModelMetaData> | void): AgencyModel;
}