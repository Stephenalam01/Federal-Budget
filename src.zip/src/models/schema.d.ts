import { Schema } from '@aws-amplify/datastore';

export declare const schema: Schema;