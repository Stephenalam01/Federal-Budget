import {AppSignOut, NewAgencyCollection, AddAgency} from "./ui-components";
import { DataStore } from "aws-amplify";
import {withAuthenticator, Divider} from "@aws-amplify/ui-react";
import './App.css';
import {AgencyModel} from "./models";
import { useState } from "react";


function App({user, signOut}) {
    const [Name, setName] = useState("");
    const [Budget, setBudget] = useState("");
    const [Departments, setDepartments] = useState("");

    const saveAgencyModel = async () => {
        try {
            await DataStore.save(
                new AgencyModel({
                  AgencyName: Name,
                  Budget: parseFloat(Budget),
                  NumberOfDepartments: parseInt(Departments)
              })   
            );     
        } catch (err) {
            console.log(err);
        }
    }

    const addAgencyOverrides = {
        "TextField29766922": {
          onChange: (event) => {
              setName(event.target.value);
          }
        },
        "TextField29766923": {
          onChange: (event) => {
              setBudget(event.target.value);
          }
        }, 
        "TextField29766924": {
          onChange: (event) => {
              setDepartments(event.target.value);
          }
        },
        "Button": {
            onClick: saveAgencyModel,
        }
    }

    const appsignoutOverrides = {
    "Button": {
      onClick: signOut,
    },
  };

  
  
  return (
    <div className="App">
      <AppSignOut overrides={appsignoutOverrides} />
      <header className="App-header">
        <AddAgency overrides={addAgencyOverrides} style={{textAlign: "left", margin: "1rem"}} />
        <Divider />
        <NewAgencyCollection />
      </header>
    </div>
  );
}

export default withAuthenticator(App);
