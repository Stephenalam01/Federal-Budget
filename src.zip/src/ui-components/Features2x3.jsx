/***************************************************************************
 * The contents of this file were generated with Amplify Studio.           *
 * Please refrain from making any modifications to this file.              *
 * Any changes to this file will be overwritten when running amplify pull. *
 **************************************************************************/

/* eslint-disable */
import React from "react";
import { getOverrideProps } from "@aws-amplify/ui-react/internal";
import { Flex, Icon, Text, View } from "@aws-amplify/ui-react";
export default function Features2x3(props) {
  const { overrides, ...rest } = props;
  return (
    <Flex
      gap="10px"
      direction="column"
      width="1440px"
      justifyContent="center"
      alignItems="center"
      position="relative"
      padding="40px 140px 40px 140px"
      backgroundColor="rgba(92,102,112,1)"
      {...rest}
      {...getOverrideProps(overrides, "Features2x3")}
    >
      <Flex
        gap="24px"
        direction="row"
        justifyContent="center"
        alignItems="center"
        shrink="0"
        alignSelf="stretch"
        objectFit="cover"
        position="relative"
        padding="0px 0px 0px 0px"
        {...getOverrideProps(overrides, "Frame 13629766636")}
      >
        <Flex
          gap="24px"
          direction="column"
          width="568px"
          grow="1"
          basis="568px"
          height="507px"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "Frame 13629766637")}
        >
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38429766638")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766639")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766640")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766641")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766642")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature A"
                  {...getOverrideProps(overrides, "Feature A")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766644"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38529766645")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766646")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766647")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766648")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766649")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature C"
                  {...getOverrideProps(overrides, "Feature C")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766651"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38629766652")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766653")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766654")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766655")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766656")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature E"
                  {...getOverrideProps(overrides, "Feature E")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766658"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
        </Flex>
        <Flex
          gap="24px"
          direction="column"
          width="568px"
          grow="1"
          basis="568px"
          height="507px"
          position="relative"
          padding="0px 0px 0px 0px"
          {...getOverrideProps(overrides, "Frame 395")}
        >
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38429766660")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766661")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766662")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766663")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766664")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature B"
                  {...getOverrideProps(overrides, "Feature B")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766666"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38529766667")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766668")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766669")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766670")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766671")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature D"
                  {...getOverrideProps(overrides, "Feature D")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766673"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
          <Flex
            gap="0"
            direction="column"
            shrink="0"
            alignSelf="stretch"
            objectFit="cover"
            position="relative"
            padding="24px 24px 24px 24px"
            backgroundColor="rgba(0,0,0,1)"
            {...getOverrideProps(overrides, "Frame 38629766674")}
          >
            <Flex
              gap="24px"
              direction="row"
              alignItems="flex-start"
              shrink="0"
              alignSelf="stretch"
              objectFit="cover"
              position="relative"
              padding="0px 0px 0px 0px"
              {...getOverrideProps(overrides, "Frame 38129766675")}
            >
              <View
                width="40px"
                height="40px"
                shrink="0"
                overflow="hidden"
                position="relative"
                padding="0px 0px 0px 0px"
                backgroundColor="rgba(0,0,0,1)"
                {...getOverrideProps(overrides, "Icon29766676")}
              >
                <Icon
                  width="30px"
                  height="30px"
                  viewBox={{ minX: 0, minY: 0, width: 30, height: 30 }}
                  paths={[
                    {
                      d: "M26.6667 0L3.33333 0C1.48333 0 0 1.5 0 3.33333L0 26.6667C0 28.5 1.48333 30 3.33333 30L26.6667 30C28.5 30 30 28.5 30 26.6667L30 3.33333C30 1.5 28.5 0 26.6667 0ZM26.6667 26.6667L3.33333 26.6667L3.33333 3.33333L26.6667 3.33333L26.6667 26.6667ZM13.3333 23.3333L16.6667 23.3333L16.6667 16.6667L23.3333 16.6667L23.3333 13.3333L16.6667 13.3333L16.6667 6.66667L13.3333 6.66667L13.3333 13.3333L6.66667 13.3333L6.66667 16.6667L13.3333 16.6667L13.3333 23.3333Z",
                      fill: "rgba(255,255,255,1)",
                      fillRule: "nonzero",
                    },
                  ]}
                  position="absolute"
                  top="12.5%"
                  bottom="12.5%"
                  left="12.5%"
                  right="12.5%"
                  {...getOverrideProps(overrides, "Vector29766677")}
                ></Icon>
              </View>
              <Flex
                gap="8px"
                direction="column"
                width="456px"
                justifyContent="center"
                grow="1"
                basis="456px"
                height="105px"
                position="relative"
                padding="0px 0px 0px 0px"
                {...getOverrideProps(overrides, "Frame 38029766678")}
              >
                <Text
                  fontFamily="Inter"
                  fontSize="20px"
                  fontWeight="700"
                  color="rgba(255,255,255,1)"
                  lineHeight="25px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Feature F"
                  {...getOverrideProps(overrides, "Feature F")}
                ></Text>
                <Text
                  fontFamily="Inter"
                  fontSize="16px"
                  fontWeight="400"
                  color="rgba(255,255,255,1)"
                  lineHeight="24px"
                  textAlign="left"
                  display="flex"
                  direction="column"
                  justifyContent="flex-start"
                  letterSpacing="0.01px"
                  shrink="0"
                  alignSelf="stretch"
                  objectFit="cover"
                  position="relative"
                  padding="0px 0px 0px 0px"
                  whiteSpace="pre-wrap"
                  children="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam."
                  {...getOverrideProps(
                    overrides,
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.29766680"
                  )}
                ></Text>
              </Flex>
            </Flex>
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
}
